The graphics under this folder came from Daniel Cooks free art collections.  The originals can be found here:

http://www.lostgarden.com/search/label/free%20game%20graphics

Note: These assets and many more can be found on Danc's site.  Additionally, Daniel has many useful and interesting articles on game design.  I strongly suggest you visit and give his site a look.

